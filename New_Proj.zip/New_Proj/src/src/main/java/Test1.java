import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.openqa.selenium.chrome.ChromeDriver;


public class Test1 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "/Users/madhura/Downloads/chromedriver 2");
		WebDriver driver = new ChromeDriver(); 
		
		// 1) Navigate to WW Studio Finder page
		driver.get("https://www.weightwatchers.com/us/find-a-workshop/");
		driver.manage().window().maximize();
		System.out.println(driver.getTitle());
		
		// 2) Assert loaded page title contains “Find WW Studios & Meetings Near You | WW USA”
		Assert.assertEquals("Find WW Studios & Meetings Near You | WW USA", driver.getTitle());
		
		// 3) Under Find your Workshop, click on Studios
		driver.findElement(By.xpath("//*[text() = 'Studio']")).click();
		
		// 4) In the search field, search for meetings for zip code: 10011
		driver.findElement(By.id("location-search")).sendKeys("10011");
		driver.findElement(By.id("location-search-cta")).click();
		
		// 5) Print the title of the first result
	
		driver.get("https://www.weightwatchers.com/us/find-a-workshop/1252089/ww-studio--chelsea-new-york-ny");
		System.out.println(driver.findElement(By.className("locationName-1jro_")).getText());
		
		// 6) Click on the first search result and then verify displayed location name/title matches with the name of the first searched result that was clicked.
		 
		String studio_name= driver.findElement(By.className("locationName-1jro_")).getText();
		if ( driver.getPageSource().contains(studio_name)){
	         System.out.println("Studio name is present. ");
	      } else {
	         System.out.println("Studio name is not present. ");
	      }
		

		// 7) Click on Business Hours
		
		driver.findElement(By.className("hoursIcon-II-H2")).click();
			
		// 8) Create a method to print all the business hours for that studio
		
		List<WebElement> list = driver.findElements(By.xpath(".//*[@class='day-CZkDC']"));
	    for(WebElement element : list) {
	       System.out.print(element.getText());
	       System.out.println();
	    }
		
		
	driver.quit();
		
	}


}